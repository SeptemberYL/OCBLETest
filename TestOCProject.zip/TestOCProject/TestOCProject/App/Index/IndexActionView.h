//
//  IndexActionView.h
//  TestOCProject
//
//  Created by lin on 2025/8/25.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface IndexActionView : UIView

//MARK: - 属性相关
/// 强引用uibutton
@property(nonatomic, strong) UIButton* connectBtn; // 蓝牙连接按钮
/// 强引用uibutton
@property(nonatomic, strong) UIButton* testBtn; // 测试密码有效按钮

//MARK: - 开放方法
/// 添加通知监听
- (void) setupNoti;

@end

NS_ASSUME_NONNULL_END
