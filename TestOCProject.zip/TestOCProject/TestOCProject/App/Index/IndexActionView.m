//
//  IndexActionView.m
//  TestOCProject
//
//  Created by lin on 2025/8/25.
//

#import "IndexActionView.h"
#import "BLEManager.h"
#import "Masonry.h"

@implementation IndexActionView

//MARK: - 初始化
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // 添加控件
        [self setupUI];
        // 添加通知监听
        [self setupNoti];
    }
    return self;
}
- (void)dealloc
{
    // 移除通知
    [NSNotificationCenter.defaultCenter removeObserver:self];
#if DEBUG
    NSLog(@"%@ ===> 被销毁了", self.description);
#endif
}

//MARK: - 懒加载属性
/// 连接按钮
- (UIButton*) connectBtn {
    // 懒加载中 判断是否有对象
    if (!_connectBtn) {
        // 无对象初始化
        _connectBtn = [self getNormalBtn:0];
    }
    return _connectBtn;
}
/// 测试密码有效按钮
- (UIButton*) testBtn {
    // 懒加载中 判断是否有对象
    if (!_testBtn) {
        // 无对象初始化
        _testBtn = [self getNormalBtn:1];
        [_testBtn setTitle:@"密码测试" forState:UIControlStateNormal];
    }
    return _testBtn;
}
/// 获取默认样式按钮
- (UIButton*) getNormalBtn:(int)tag{
    // 无对象初始化
    UIButton* btn = [[UIButton alloc] init];
    // 设定属性
    btn.layer.cornerRadius = 12;
    // 0.3不透明度黑色
    btn.backgroundColor = [UIColor.blackColor colorWithAlphaComponent:0.3];
    // 设置标题 这部分似乎与swift不同 无法直接.normal去使用属性
    [btn setTitle:@"" forState: UIControlStateNormal];
    [btn setTitleColor:UIColor.labelColor forState:UIControlStateNormal];
    // 添加点击事件
    btn.tag = tag;
    [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    
    return btn;
}

//MARK: - UI
/// 添加控件设置约束
- (void) setupUI {
    // 连接按钮
    [self addSubview:self.connectBtn];
    // 测试密码按钮
    [self addSubview:self.testBtn];
    // 设置约束
    // 连接按钮
    [self.connectBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.equalTo(self);
        make.centerY.equalTo(self);
        // 宽度写死100
        make.width.equalTo(@100);
        // 居左
        make.leading.equalTo(self);
    }];
    // 测试密码有效按钮
    [self.testBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.height.centerY.equalTo(self.connectBtn);
        make.trailing.equalTo(self);
        make.leading.equalTo(self.connectBtn.mas_trailing).offset(50);
    }];
}


//MARK: - 事件
/// 按钮点击事件
- (void) btnClick : (UIButton *)btn { // 传入btn 通过tag判断
#if DEBUG // debug状态下才触发打印,实际项目需要封装成 **log 方便使用
    // 打印点击按钮标题
    NSLog(@"点击%@按钮", btn.titleLabel.text);
#endif
    // 判断按钮
    switch (btn.tag) {
        case 0:
            // 搜索设备
            [BLEManager.sharedManager search];
            break;
        case 1 : // 测试算法
            NSString* password = @"111211";
            // 验证算法
            Boolean canUse = [self testVerifyPassword:password];
            NSLog(canUse ? @"密码可用" : @"密码不可用");
            break;
    }
}

/// 测试验证密码有效
/// - Parameter password: 传入密码
/// - Return : 返回是否有效
- (Boolean) testVerifyPassword:(NSString*)password {
    // 空字符串无效
    if (!password || [password length] == 0) {
        return NO;
    }
    /// 第一个字符
    unichar firstChar = [password characterAtIndex:0];
    
    // 检查后续5个字符是否与第一个相同
    for (NSUInteger i = 1; i < password.length; i++) {
        // 不相等就直接break掉
        if ([password characterAtIndex:i] != firstChar) {
            break;
        } else if (i == password.length - 1) {
            // 最后一位
            return false; // 完全一致 不允许
        }
    }
    /// 升序还是降序
    Boolean isBigger = true;
    for (NSUInteger i = 1; i < [password length]; i++) {
        /// 左边字符
        NSString *leftChar = [password substringWithRange:NSMakeRange(i - 1, 1)];
        /// 右边字符
        NSString *rightChar = [password substringWithRange:NSMakeRange(i, 1)];
        /// 差值
        NSInteger diff = rightChar.intValue - leftChar.intValue;
        
        // 判断绝对值
        if (labs(diff) != 1) {
            return true; // 绝对值不为1那么有效
        }
        // 如果是第二个字符那么判断 升序降序
        if (i == 1) {
            isBigger = diff > 0;
            // 结束本次判断
            continue;
        }
        // 升序 降序
        if ((isBigger && diff == 1) || (!isBigger && diff == -1)) {
            continue; // 下一个字符判断
        } else {
            // 有效 规则不符合
            return true;
        }
    }
    // 如果有效那么在上面已经退出循环了
    return false;
}

/// 设置通知监听
- (void) setupNoti {
    /// 弱引用防止循环引用
    __weak IndexActionView *weakSelf = self;
    // 添加监听
    [NSNotificationCenter.defaultCenter addObserverForName:@"BLEStateUpdate" object:nil queue:nil usingBlock:^(NSNotification * _Nonnull notification) {
        if (weakSelf) {
            [weakSelf BLEStateUpdate];
        }
    }];
}

- (void) BLEStateUpdate{
    /// 提示语
    NSString *tipsString = @"";
    // 枚举判断状态
    switch (BLEManager.sharedManager.state) {
        case BLEStateNotOpen: // 默认状态 未开启蓝牙
            tipsString = @"未开启";
            break;
        case BLEStateSearching: // 搜索中
            tipsString = @"搜索中";
            break;
        case BLEStateNotAuth: // 未授权
            tipsString = @"未授权";
            break;
        case BLEStateConnect: // 已连接
            tipsString = @"已连接";
            break;
        default:
            break;
    }
    // 修改按钮标题
    [_connectBtn setTitle:tipsString forState:UIControlStateNormal];
}

@end

//(void) YLLog : (NSString *)format, ... {
//#if DEBUG // debug状态下才触发打印,实际项目需要封装
//    // 打印点击按钮标题
//    NSLog(@"%@", format);
//#endif
//}
