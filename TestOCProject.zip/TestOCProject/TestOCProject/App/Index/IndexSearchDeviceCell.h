//
//  IndexSearchDeviceCell.h
//  TestOCProject
//
//  Created by lin on 2025/8/26.
//

#import <UIKit/UIKit.h>
#import "CoreBluetooth/CoreBluetooth.h"

NS_ASSUME_NONNULL_BEGIN

@interface IndexSearchDeviceCell : UITableViewCell

//MARK: - 属性
/// 资源对象
@property(nonatomic, assign) CBPeripheral* peripheral;

//MARK: - 控件
/// 名称
@property(nonatomic, strong) UILabel* nameLab;

@end

NS_ASSUME_NONNULL_END
