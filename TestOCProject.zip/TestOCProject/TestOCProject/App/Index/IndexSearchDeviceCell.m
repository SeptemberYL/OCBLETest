//
//  IndexSearchDeviceCell.m
//  TestOCProject
//
//  Created by lin on 2025/8/26.
//

#import "IndexSearchDeviceCell.h"
#import "Masonry.h" // 约束 应该写个头文件引入的

@implementation IndexSearchDeviceCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
/// 初始化方法
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    // 修改
    if (self) {
        [self setupUI];
    }
    return self;
}
//MARK: - UI
/// 设置控件与约束
- (void)setupUI {
    // 设置底色
    self.backgroundColor = [UIColor.systemPinkColor colorWithAlphaComponent:0.3];
    // 禁止点击样式
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    _nameLab = [[UILabel alloc] init];
    _nameLab.font = [UIFont systemFontOfSize:24 weight:UIFontWeightSemibold];
    _nameLab.textColor = UIColor.labelColor;
    // 添加控件
    [self addSubview: _nameLab];
    // 设置约束
    [_nameLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self).insets(UIEdgeInsetsMake(10, 0, 10, 0));
    }];
}

//MARK: - 事件
// 设置资源监听
- (void)setPeripheral:(CBPeripheral *)peripheral {
    _peripheral = peripheral;
    // 修改展示
    self.nameLab.text = peripheral.name;
}

@end
