//
//  IndexSearchDeviceTableView.h
//  TestOCProject
//
//  Created by lin on 2025/8/26.
//

#import <UIKit/UIKit.h>
#import "IndexSearchDeviceCell.h"
#import "BLEManager.h"

NS_ASSUME_NONNULL_BEGIN

@interface IndexSearchDeviceTableView : UITableView <UITableViewDelegate, UITableViewDataSource>

/// cell复用名
@property(nonatomic, readonly) NSString *cellReuseIdentifier;

@end

NS_ASSUME_NONNULL_END
