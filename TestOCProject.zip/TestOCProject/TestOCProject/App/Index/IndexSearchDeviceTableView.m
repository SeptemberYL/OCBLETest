//
//  IndexSearchDeviceTableView.m
//  TestOCProject
//
//  Created by lin on 2025/8/26.
//

#import "IndexSearchDeviceTableView.h"

@implementation IndexSearchDeviceTableView

//MARK: - 属性相关

//MARK: - 方法
- (instancetype)initWithFrame:(CGRect)frame style:(UITableViewStyle)style {
    // 设置cell复用名
    _cellReuseIdentifier = @"IndexSearchDeviceCell";
    // 初始化
    self = [super initWithFrame:frame style:style];
    // 设置基本属性
    // 不要分隔线
    self.separatorStyle = UITableViewCellSeparatorStyleNone;
    // 不要滑动条
    self.showsVerticalScrollIndicator = false;
    self.showsHorizontalScrollIndicator = false;
    // 透明底色
    self.backgroundColor = [UIColor.orangeColor colorWithAlphaComponent:0.3];
    // 注册cell
    [self registerClass:IndexSearchDeviceCell.self forCellReuseIdentifier: self.cellReuseIdentifier];
    // 设置代理
    self.delegate = self;
    self.dataSource = self;
    // 安全区
    CGFloat safeBottom = UIApplication.sharedApplication.keyWindow.safeAreaLayoutGuide.layoutFrame.size.height;
    // 设置安全间距
    self.contentInset = UIEdgeInsetsMake(0, 0, safeBottom, 0);
    
    /// 弱引用防止循环引用
    __weak IndexSearchDeviceTableView *weakSelf = self;
    // 通知监听
    [NSNotificationCenter.defaultCenter addObserverForName:@"searchPeripheralArrayUpdate" object:nil queue:nil usingBlock:^(NSNotification * _Nonnull notification) {
        // 直接调用刷新
        [weakSelf reloadData]; // 生产环境需要优化一下逻辑 到主线程调用
    }];
    
    return self;
}
- (void)dealloc
{
    // 移除通知
    [NSNotificationCenter.defaultCenter removeObserver:self];
    NSLog(@"被销毁了");
}

//MARK: - 代理
// 返回有多少个cell
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSLog(@"%d", BLEManager.sharedManager.searchPeripheralArray.count);
    return BLEManager.sharedManager.searchPeripheralArray.count;
}
// 设置cell样式
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    /// cell
    IndexSearchDeviceCell* cell = [tableView dequeueReusableCellWithIdentifier:self.cellReuseIdentifier forIndexPath:indexPath];
    // 通过model设置内部属性(这里简写直接传对象)
    cell.peripheral = BLEManager.sharedManager.searchPeripheralArray[indexPath.row];
    
    return cell;
}
// 点击cell
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // 防越界
    if (indexPath.row >= BLEManager.sharedManager.searchPeripheralArray.count) {
        return;
    }
    // 点击设备
    CBPeripheral *peripheral = BLEManager.sharedManager.searchPeripheralArray[indexPath.row];
#if DEBUG
    // 打印信息
    NSLog(@"用户想链接%@的设备", peripheral.name);
#else
    // 测试机设备隔离 不做链接
    // 连接
    [BLEManager.sharedManager connect:peripheral];
#endif
}

@end
