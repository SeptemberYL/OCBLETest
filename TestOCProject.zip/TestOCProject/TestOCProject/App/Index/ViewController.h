//
//  ViewController.h
//  TestOCProject
//
//  Created by lin on 2025/8/25.
//

#import <UIKit/UIKit.h>
#import "IndexActionView.h"
#import "IndexSearchDeviceTableView.h"

@interface ViewController : UIViewController
//MARK: - 属性相关

//MARK: - 控件相关
/// 事件view
@property (nonatomic) IndexActionView* actionView;
/// 设备view
@property (nonatomic) IndexSearchDeviceTableView* deviceView;

@end

