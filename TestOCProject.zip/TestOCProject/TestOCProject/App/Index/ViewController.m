//
//  ViewController.m
//  TestOCProject
//
//  Created by lin on 2025/8/25.
//

#import "ViewController.h"
#import "SnapKit-Swift.h"
#import "Masonry.h"

@interface ViewController ()


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 设置控件
    [self setupUI];
    // Do any additional setup after loading the view.
    
}

//MARK: - 懒加载
/// 事件view
- (IndexActionView*) actionView {
    // 懒加载中 判断是否有对象
    if (!_actionView) {
        // 无对象初始化
        _actionView = [[IndexActionView alloc] init];
    }
    return _actionView;
}
/// 设备view
- (IndexSearchDeviceTableView*) deviceView {
    // 懒加载中 判断是否有对象
    if (!_deviceView) {
        // 无对象初始化
        _deviceView = [[IndexSearchDeviceTableView alloc] init];
    }
    return _deviceView;
}

//MARK: - UI
/// 设置ui组件
- (void) setupUI {
    // 页面底色
    self.view.backgroundColor = UIColor.whiteColor;
    // 添加控件
    [self.view addSubview: self.actionView];
    // 添加控件
    [self.view addSubview: self.deviceView];
    // 设置约束
//    _actionView.snp // 导入snp但发现不与oc兼容,现在用masonry,虽然用frame写也可以,不过想学一下oc的自动布局
    // 原oc 单约束写法
//    [self.view addConstraints:@[
//        [NSLayoutConstraint constraintWithItem:self.actionView
//                                     attribute:NSLayoutAttributeCenterY
//                                     relatedBy:NSLayoutRelationEqual
//                                        toItem:self.view
//                                     attribute:NSLayoutAttributeCenterY
//                                    multiplier:1.0
//                                      constant:0
//        ]
//    ]];
    // masnory写法
    // 事件view
    [self.actionView mas_makeConstraints:^(MASConstraintMaker *make) {
        // centerY居中
//        make.centerY.equalTo(self.view.mas_centerY);
        /// 状态栏高度
        CGFloat statusHeight = [UIApplication.sharedApplication statusBarFrame].size.height;
        make.top.equalTo(self.view.mas_top).with.offset(statusHeight + 44);
        // centerX居中
        make.centerX.equalTo(self.view.mas_centerX);
        // 高度写死100先
        make.height.equalTo(@100);
        // 居中 内部撑开高度
        make.centerX.equalTo(self.view);
    }];
    // 设备view
    [self.deviceView mas_makeConstraints:^(MASConstraintMaker *make) {
        // 居事件view底部
        make.top.equalTo(self.actionView.mas_bottom).with.offset(20);
        // 撑开到底部栏
        make.leading.and.trailing.and.bottom.equalTo(self.view);
    }];
}






@end
