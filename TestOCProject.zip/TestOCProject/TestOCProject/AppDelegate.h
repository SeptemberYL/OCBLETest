//
//  AppDelegate.h
//  TestOCProject
//
//  Created by lin on 2025/8/25.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property(nonatomic) UIWindow* window;

@end

