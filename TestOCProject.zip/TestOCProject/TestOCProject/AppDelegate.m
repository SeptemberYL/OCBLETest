//
//  AppDelegate.m
//  TestOCProject
//
//  Created by lin on 2025/8/25.
//

#import "AppDelegate.h"
#import "ViewController.h" // 导入需要使用到的oc文件

@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // 初始化uiwindow
    _window = [UIWindow new];
    /// 控制器
    ViewController *vc = [[ViewController alloc] init];
    /// 导航栏
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    // 设置主控制器
    _window.rootViewController = nav;
    // 激活
    [_window makeKeyAndVisible];
    // Override point for customization after application launch.
    return YES;
}

@end
