//
//  BLEManager.h
//  TestOCProject
//
//  Created by lin on 2025/8/25.
//

#import <Foundation/Foundation.h>
#import "CoreBluetooth/CoreBluetooth.h" // 蓝牙连接框架

/// 蓝牙连接状态
typedef enum _BLEState : int {
    /// 未开启
    BLEStateNotOpen,
    /// 搜索中
    BLEStateSearching,
    /// 未授权
    BLEStateNotAuth,
    /// 已连接
    BLEStateConnect,
} BLEState;


/// 蓝牙连接单例
@interface BLEManager : NSObject <CBCentralManagerDelegate, CBPeripheralDelegate> // 蓝牙搜索代理,蓝牙连接代理

// 强制有值 类似!
NS_ASSUME_NONNULL_BEGIN
/**
 * Returns global shared manager instance.
 * 返回全局单例,使用了SDWebImageManager的写法
 */
@property (nonatomic, class, readonly, nonnull) BLEManager *sharedManager;

/// ble连接单例
@property (nonatomic, strong) CBCentralManager *centralManager;

/// 当前连接状态
@property (nonatomic, assign) BLEState state; // 值类型

/// 当前搜索到的设备
@property (nonatomic, strong) NSMutableArray<CBPeripheral *>* searchPeripheralArray; // 由于是对象地址,所以不能用set方法监听值的改变
NS_ASSUME_NONNULL_END

/// 连接设备 可能为空
@property (nonatomic, strong) CBPeripheral* _Nullable connectedPeripheral;


//MARK: - 事件相关
/// 搜索
- (void)search;
/// 连接
- (void)connect:(CBPeripheral *)peripheral;

@end


