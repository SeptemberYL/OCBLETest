//
//  BLEManager.m
//  TestOCProject
//
//  Created by lin on 2025/8/25.
//

#import "BLEManager.h"

/**
 BLE传输协议 蓝牙链接单例
 */

@implementation BLEManager

/**
 nonnull关键字作用 类似swift中! 强制不为空
 instancetype使非关联返回类型的方法返回所在类的类型 即 a的instancetype方法 返回a
 dispatch_once_t 线程安全,让alloc init与share为同一个对象
 
 */
/// 共享单例
+ (nonnull instancetype)sharedManager {
    static dispatch_once_t once;
    /// 任意类型对象
    static id instance;
    // 调用dispatch_once获取与唯一的sharedManager
    dispatch_once(&once, ^{
        instance = [[self alloc] init];
    });
    // 传出
    return instance;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        // 初始化管理器
        _centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil options:nil];
        // 初始化搜索到的
        _searchPeripheralArray = [[NSMutableArray alloc] init];
        // 枚举状态默认值
        _state = BLEStateNotOpen;
    }
    return self;
}

//MARK: - 事件方法
/// 搜索
- (void)search{
    // 正在搜索不执行
    if (self.centralManager.isScanning) {
        return;
    }
    // 已开启蓝牙 && 不在搜索
    if (self.centralManager.state == CBManagerStatePoweredOn) {
        // 开始扫描设备 (第一个入参指定只搜索哪些uid设备 为空就是全搜素)
        [self.centralManager scanForPeripheralsWithServices:nil options:nil];
        // 进入搜索状态
        self.state = BLEStateSearching;
    } else if (self.centralManager.state == CBManagerStateUnauthorized) {
        // 未授权 弹窗提示用户
#if DEBUG
        NSLog(@"蓝牙未授权");
#endif
    } else {
        // 未开启 弹窗提示用户
#if DEBUG
        NSLog(@"蓝牙未开启或其他异常");
#endif
    }
}
/// 链接设备
- (void)connect:(CBPeripheral *)peripheral {
    // 连接设备
    [self.centralManager connectPeripheral:peripheral options:nil];
}

/// 修改状态
/// - Parameter state: 状态
- (void)setState:(BLEState)state {
    // 修改
    _state = state;
    // 发送通知
    [NSNotificationCenter.defaultCenter postNotificationName:@"BLEStateUpdate" object:nil];
}
/// 修改搜索到的设备
/// - Parameter searchPeripheralArray: 搜索到的设备
- (void)addObjectToSearchPeripheralArray:(CBPeripheral *)peripheral {
    // 添加
    [self.searchPeripheralArray addObject:peripheral];
    // 发送通知
    [NSNotificationCenter.defaultCenter postNotificationName:@"searchPeripheralArrayUpdate" object:nil];
}

//MARK: - 代理
// 状态更新回调
- (void)centralManagerDidUpdateState:(CBCentralManager *)central {
    // 已开启蓝牙
    if (central.state == CBManagerStatePoweredOn) {
        if (central.isScanning) {
            // 开启状态
            self.state = BLEStateSearching;
        } else {
            // 未开启
            self.state = BLEStateNotOpen;
        }
    } else if (central.state == CBManagerStateUnauthorized) {
        // 未授权
        self.state = BLEStateNotAuth;
    } else {
        // 未开启
        self.state = BLEStateNotOpen;
        NSLog(@"蓝牙不可用，状态：%ld", (long)central.state);
    }
}

// 发现设备回调
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary<NSString *,id> *)advertisementData RSSI:(NSNumber *)RSSI {
#if DEBUG
    /// 模拟用户最后一次连接设备
    NSString *lastConnectUID = @"B28255DF-05C4-1295-E275-2AED667ED418";
#else
    /// userdefaults
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    /// 最后一次连接设备
    NSString *lastConnectUID = [defaults objectForKey:@"lastConnectUID"]; // 非生产环境需要到userdefault等地方去取
#endif
    // 名称为空 排除该设备
    if (peripheral.name == NULL) {
        return;
    }
    // 有名称且列表中没有该设备
    if (![self.searchPeripheralArray containsObject:peripheral]) {
        // 搜寻设备+1
        [self addObjectToSearchPeripheralArray:peripheral];
    }
    // 使用UUID过滤设备
    if ([peripheral.identifier.UUIDString containsString:lastConnectUID]) {
        // 存储本次链接
        self.connectedPeripheral = peripheral;
        // 设置代理
        self.connectedPeripheral.delegate = self;
        // 停止搜索
        [self.centralManager stopScan];
        // 连接设备
        [self.centralManager connectPeripheral:peripheral options:nil];
    }
}


// 成功连接设备
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral {
    NSLog(@"已连接设备：%@", peripheral.name);
    // 已连接状态
    self.state = BLEStateConnect;
    [peripheral discoverServices:nil]; // 发现所有服务
}
// 发现服务后
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error {
    for (CBService *service in peripheral.services) {
        NSLog(@"发现服务：%@", service.UUID);
        [peripheral discoverCharacteristics:nil forService:service];
    }
}
// 发现特征后
- (void)peripheral:(CBPeripheral *)peripheral
didDiscoverCharacteristicsForService:(CBService *)service
             error:(NSError *)error {
    
    for (CBCharacteristic *characteristic in service.characteristics) {
        NSLog(@"发现特征：%@", characteristic.UUID);
        
        // 订阅通知
        if (characteristic.properties & CBCharacteristicPropertyNotify) {
            [peripheral setNotifyValue:YES forCharacteristic:characteristic];
        }
        
        // 读取初始值
        if (characteristic.properties & CBCharacteristicPropertyRead) {
            [peripheral readValueForCharacteristic:characteristic];
        }
    }
}

//MARK: - 收发信息
// 接收到外设返回的数据
- (void)peripheral:(CBPeripheral *)peripheral
 didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic
             error:(NSError *)error {
    /// 收到的信息
    NSData *data = characteristic.value;
    // 将收到的nsdata 转为hex编码格式
//    NSString *hexStr = [ParseDataTool transDataToHexString:data];
//    NSLog(@"接收到数据: %@", hexStr);
}

// 向设备发送数据
- (void)writeData:(NSData *)data toCharacteristic:(CBCharacteristic *)characteristic {
    [self.connectedPeripheral writeValue:data
                        forCharacteristic:characteristic
                                     type:CBCharacteristicWriteWithResponse];
}



@end
