//
//  main.m
//  TestOCProject
//
//  Created by lin on 2025/8/25.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

// main函数
int main(int argc, char * argv[]) {
    // appdelegate的类名称
    NSString * appDelegateClassName;
    @autoreleasepool {
        // 通过获取appdelegate的列名称 传值进入appDelegateClassName属性
        // Setup code that might create autoreleased objects goes here.
        appDelegateClassName = NSStringFromClass([AppDelegate class]);
    }
    // 返回当前主控
    return UIApplicationMain(argc, argv, nil, appDelegateClassName);
}
